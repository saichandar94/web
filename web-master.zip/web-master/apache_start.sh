#!/bin/bash
 
service httpd restart